title: Android 百度离线地图的使用
date: '2019-08-18 03:19:40'
updated: '2019-08-18 03:19:40'
tags: [Android]
permalink: /articles/2019/08/18/1566069580153.html
---
### 一、离线地图 sdk 的使用

```java
val offlineMap = MKOfflineMap()
        offlineMap.init { type, state ->
            when (type) {
                MKOfflineMap.TYPE_DOWNLOAD_UPDATE -> {//离线地图下载
                    val update = offlineMap.getUpdateInfo(state)
                    if (update != null) {
                        Log.i(TAG, String.format("%s : %d%%", update!!.cityName, update!!.ratio))
                    }
                }
                MKOfflineMap.TYPE_NETWORK_ERROR -> {//离线地图网络问题

                }
                MKOfflineMap.TYPE_NEW_OFFLINE -> {//新安装离线地图

                }
                MKOfflineMap.TYPE_VER_UPDATE -> {//离线地图数据版本更新

                }

            }
        }
        //获取所有城市列表
        val offlineCityList = offlineMap.offlineCityList
        //热门城市
        val hotCityList = offlineMap.hotCityList
        //下载离线包
        offlineMap.start(1)
        //暂停下载
        offlineMap.pause(1)
        //删除离线包
        offlineMap.remove(1)
        //更新离线包
        offlineMap.update(1)
```

### 二、在内网环境下的使用

1、首先找到离线包在内存卡下的存放路径，这样我们可以在内网上通过下载或其他方式将离线包放到对应的位置，这样不就可以了。

通过查找，离线包位置在：Android/data/包名/files/BaiduMapSDKNew

![156258843090391ce52a750ed44f8938b695ed198570e.jpg](https://img.hacpai.com/file/2019/08/156258843090391ce52a750ed44f8938b695ed198570e-e075c58d.jpg)


2、新建一个项目，创建对应的路径，将离线包复制过去，打开地图，发现离线地图并没有展示，通过观察，发现 vmp 文件夹下还有一个 **DVUserdata.cfg** 文件，打开如下：

```json
[
  {
    "sx" : 12128434,
    "fm" : 4000,
    "sspatchs" : 6355275,
    "sy" : 4040943,
    "lu" : 0,
    "ldt" : 0,
    "lv" : 752,
    "spatchs" : 10674476,
    "sgs" : 0,
    "bb" : 262144,
    "lcurv" : 0,
    "lx" : 12128434,
    "lss" : 6355275,
    "ly" : 4040943,
    "sd" : 2,
    "sforce" : 0,
    "sgv" : 0,
    "lsu" : 0,
    "lcurs" : 0,
    "sh" : "qggl",
    "ld" : 4,
    "si" : 1,
    "lnote" : 0,
    "lsv" : 20190422,
    "sscurs" : 0,
    "sfm" : 0,
    "bl" : 8126464,
    "sl" : 4,
    "lh" : "qggl",
    "sdt" : 0,
    "li" : 1,
    "lcontrol" : 0,
    "sn" : "È«¹ú»ù´¡°ü",
    "lgs" : 0,
    "sss" : 6355275,
    "sp" : "quanguogailue",
    "scurs" : 0,
    "ll" : 4,
    "lforce" : 0,
    "lpatchs" : 0,
    "snote" : 0,
    "br" : 15073280,
    "sr" : 100,
    "ln" : "È«¹ú»ù´¡°ü",
    "scontrol" : 0,
    "ss" : 10674476,
    "ssu" : 0,
    "lspatchs" : 0,
    "lscurs" : 0,
    "bt" : 7077888,
    "lp" : "quanguogailue",
    "lgv" : 0,
    "su" : 0,
    "ssv" : 20190422,
    "sv" : 752,
    "lr" : 100,
    "ls" : 10674476
  },
  {
    "sx" : 12127997,
    "fm" : 4000,
    "sspatchs" : 6527160,
    "sy" : 4051196,
    "lu" : 0,
    "ldt" : 0,
    "lv" : 782,
    "spatchs" : 59529305,
    "sgs" : 0,
    "bb" : 3964416,
    "lcurv" : 0,
    "lx" : 12127997,
    "lss" : 6527160,
    "ly" : 4051196,
    "sd" : 2,
    "sforce" : 0,
    "sgv" : 0,
    "lsu" : 0,
    "lcurs" : 0,
    "sh" : "xa",
    "lgdir" : "\/storage\/emulated\/0\/Android\/data\/cn.test.offlinemap\/files\/BaiduMapSDKNew\/offline\/233\/",
    "ld" : 4,
    "si" : 233,
    "lnote" : 0,
    "lsv" : 20190422,
    "sscurs" : 0,
    "sfm" : 0,
    "bl" : 11985408,
    "sl" : 12,
    "lh" : "xa",
    "sdt" : 0,
    "li" : 233,
    "lcontrol" : 0,
    "sn" : "Î÷°²ÊÐ",
    "lgs" : 0,
    "sss" : 6527160,
    "sp" : "xian_233",
    "scurs" : 0,
    "ll" : 12,
    "lforce" : 0,
    "lpatchs" : 0,
    "snote" : 0,
    "br" : 12226560,
    "sr" : 100,
    "ln" : "Î÷°²ÊÐ",
    "scontrol" : 0,
    "ss" : 59529305,
    "ssu" : 0,
    "lspatchs" : 0,
    "lscurs" : 0,
    "bt" : 4105216,
    "lp" : "xian_233",
    "lgv" : 0,
    "su" : 0,
    "ssv" : 20190422,
    "sv" : 782,
    "lr" : 100,
    "ls" : 59529305
  }
]
```

把这个文件再复制过去，地图就在断网的情况下展示了，这个配置文件每下载一个离线包，会多一个配置节点，我们根据这个规则动态生成就好了。
