title: linux 下 Mysql 中文乱码
date: '2019-07-03 23:14:22'
updated: '2019-07-03 23:14:22'
tags: [java]
permalink: /articles/2019/07/03/1562166862000.html
---
安装完 MySQL 的默认字符集为 latin1,中文就会出现乱码的情况，解决这种情况，就需要改相关的配置文件，然后重启服务就生效了。  
  
#### 1、查看默认字符集  
```  
#登陆root用户  
mysql> show variables like 'character_set%';  
```  
![20180601104055944.png](https://img.hacpai.com/file/2019/08/20180601104055944-ed09e411.png)
  
#### 2、修改字符集 配置文件 ，文件目录  ```/etc/my.cnf```  
  
```  
[client]  
default-character-set=utf8  
   
[mysqld]  
datadir=/var/lib/mysql  
socket=/var/lib/mysql/mysql.sock  
user=mysql  
# Disabling symbolic-links is recommended to prevent assorted security risks  
symbolic-links=0  
#default-character-set=utf8  
character-set-server=utf8  
init_connect='SET NAMES utf8'  
   
[mysql]  
no-auto-rehash  
default-character-set=utf8  
   
[mysqld_safe]  
log-error=/var/log/mysqld.log  
pid-file=/var/run/mysqld/mysqld.pid  
  
```  
  
#### 3、重启服务  
  
* 启动  ```service mysqld start```  
* 停止  ```service mysqld stop```  
* 重启  ```service mysqld restart```