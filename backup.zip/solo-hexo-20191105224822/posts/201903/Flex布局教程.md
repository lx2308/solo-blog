title: Flex 布局教程
date: '2019-03-10 15:34:22'
updated: '2019-03-10 15:34:22'
tags: [前端]
permalink: /articles/2019/03/10/1552203262000.html
---
#### 一、Flex 布局是什么？
Flex 是 Flexible Box 的缩写，意为"弹性布局"，用来为盒状模型提供最大的灵活性。

任何一个容器都可以指定为 Flex 布局。

```
.box{
  display: flex;
}
```
行内元素也可以使用 Flex 布局。

```
.box{
  display: inline-flex;
}
```
Webkit 内核的浏览器，必须加上```-webkit```前缀。

```
.box{
  display: -webkit-flex; /* Safari */
  display: flex;
}

```
>*注意，设为 Flex 布局以后，子元素的float、clear和vertical-align属性将失效*

![22188bbf58812dfcac77dcad09b153de948729d6755d7ec6702a7.png](https://img.hacpai.com/file/2019/08/22188bbf58812dfcac77dcad09b153de948729d6755d7ec6702a7-b002f84b.png)


#### 二、容器的属性
```
flex-direction
flex-wrap
flex-flow
justify-content
align-items
align-content
```
##### 2.1 flex-direction 属性
```flex-direction``` 属性决定主轴的方向。

```
.box {
  flex-direction: row | row-reverse | column | column-reverse;
}
```
* row（默认值）：主轴为水平方向，起点在左端。
* row-reverse：主轴为水平方向，起点在右端。
* column：主轴为垂直方向，起点在上沿。
* column-reverse：主轴为垂直方向，起点在下沿。

![flex001548bd95877f44ac299693703a8b0ac05.jpg](https://img.hacpai.com/file/2019/08/flex001548bd95877f44ac299693703a8b0ac05-e6a8a6e1.jpg)

##### 2.2 flex-wrap属性
```
.box{
  flex-wrap: nowrap | wrap | wrap-reverse;
}
```
2.2.1 nowrap 不换行

![flexwarp0118e8642863b544499984f8feb7dbded8.jpg](https://img.hacpai.com/file/2019/08/flexwarp0118e8642863b544499984f8feb7dbded8-82ede9cf.jpg)


2.2.2 wrap 正序换行

![flexwarp022ec8b915d47f43829693a7a2c4ac97ff.jpg](https://img.hacpai.com/file/2019/08/flexwarp022ec8b915d47f43829693a7a2c4ac97ff-b5ad2a09.jpg)

2.2.3 wrap-reverse 按行倒序换行

![flexwarp03fb382ddb88ba48c98b8f6d9d03ab2601.jpg](https://img.hacpai.com/file/2019/08/flexwarp03fb382ddb88ba48c98b8f6d9d03ab2601-c9e3afe7.jpg)

##### 2.3 flex-flow 属性

```flex-flow```属性是```flex-direction```属性和```flex-wrap```属性的简写形式，默认值为```row nowrap```

```
.box {
  flex-flow: <flex-direction> || <flex-wrap>;
}
```

##### 2.4 justify-content属性
```justify-content```属性定义了项目在主轴上的对齐方式。

```
.box {
  justify-content: flex-start | flex-end | center | space-between | space-around;
}
```
* flex-start（默认值）：左对齐
* flex-end：右对齐
* center： 居中
* space-between：两端对齐，项目之间的间隔都相等。
* space-around：每个项目两侧的间隔相等。所以，项目之间的间隔比项目与边框的间隔大一倍。

![flex00225d5d230dbab436a9d3f1a6e11ed1ae0.jpg](https://img.hacpai.com/file/2019/08/flex00225d5d230dbab436a9d3f1a6e11ed1ae0-8bce5a19.jpg)


##### 2.5 align-items属性

```align-items```属性定义项目在交叉轴上如何对齐。

```
.box {
  align-items: flex-start | flex-end | center | baseline | stretch;
}

```
* flex-start：交叉轴的起点对齐。
* flex-end：交叉轴的终点对齐。
* center：交叉轴的中点对齐。
* baseline: 项目的第一行文字的基线对齐。
* stretch（默认值）：如果项目未设置高度或设为auto，将占满整个容器的高度。

![flex003a6b709f4fa614314b525f6579e8d705d.jpg](https://img.hacpai.com/file/2019/08/flex003a6b709f4fa614314b525f6579e8d705d-193c2489.jpg)

##### 2.6 align-content属性
```align-content```属性定义了多根轴线的对齐方式(*即元素存在多行的时候*)。如果项目只有一根轴线， 该属性不起作用。

>使用方法同 ```align-items ```

```
.box {
  align-content: flex-start | flex-end | center | space-between | space-around | stretch;
}
```

#### 三、项目的属性

* order 属性定义项目的排列顺序。数值越小，排列越靠前，默认为0;
* flex-grow 属性定义项目的放大比例，默认为0，即如果存在剩余空间，也不放大;
* flex-shrink 属性定义了项目的缩小比例，默认为1，即如果空间不足，该项目将缩小;
* flex-basis 属性定义了在分配多余空间之前，项目占据的主轴空间（main size）。浏览器根据这个属性，计算主轴是否有多余空间。它的默认值为auto，即项目的本来大小。
* flex flex属性是flex-grow, flex-shrink 和 flex-basis的简写，默认值为0 1 auto。后两个属性可选。
* align-self 属性允许单个项目有与其他项目不一样的对齐方式，可覆盖align-items属性。默认值为auto，表示继承父元素的align-items属性，如果没有父元素，则等同于stretch。

##### 3.1 flex-grow属性

```
.box-1{
 flex-grow: 1;
}

.box-1{
  flex-grow: 2;
}

```
效果如下：

![flex004cb52a7e1d7124bd0954bba91a805b222.jpg](https://img.hacpai.com/file/2019/08/flex004cb52a7e1d7124bd0954bba91a805b222-0fa34acd.jpg)

##### 3.1 flex-shrink属性

![flex0056ed02c86fede49d3a9708f79351d5e65.jpg](https://img.hacpai.com/file/2019/08/flex0056ed02c86fede49d3a9708f79351d5e65-58842cff.jpg)

> 为1的等比缩小 ，为2时缩小的比1的小一倍，为0不缩小