title: CentOS 下 Openfire 的安装和配置
date: '2019-05-22 22:14:22'
updated: '2019-05-22 22:14:22'
tags: [java]
permalink: /articles/2019/05/22/1558534462000.html
---
## CentOS 下 Openfire 的安装和配置  
  
### 一、安装 Openfire  
  
1、下载tar包到电脑  
  
2、加压tar包  
  
```  
tar -xvf openfire_4_2_3.tar.gz  
```  
3、启动 Openfire  
  
```  
cd openfire/bin #进入 bin 目录  
openfire start  #启动openfire  
openfire stop   #停止openfire  
```  
  
### 二、配置 Openfire  
  
等 openfire 启动后，在浏览器输入 *<span style="color:red">[ip地址:9090]</span>*，就打开了设置界面，如下：  
  
1、设置语言，可以选中文  
  
![155904087431786511b13202546a09b4d7d78d3836f38.jpg](https://img.hacpai.com/file/2019/08/155904087431786511b13202546a09b4d7d78d3836f38-fddb676a.jpg)

  
2、服务器设置，默认即可  

![服务设置7667bdb4a02341d280f4e41b77bca8e7.jpg](https://img.hacpai.com/file/2019/08/服务设置7667bdb4a02341d280f4e41b77bca8e7-327ce802.jpg)

3、数据库设置，如果没有数据库，可以 HSQLDB ，效率不如外部数据库，这里使用 mysql 数据库进行配置  

![数据库设置af19223a63324d26bc28f7d130ae7a3f.jpg](https://img.hacpai.com/file/2019/08/数据库设置af19223a63324d26bc28f7d130ae7a3f-19d91a8d.jpg)

  
![1559040995713666922e5b145443483b48386475c9f47.jpg](https://img.hacpai.com/file/2019/08/1559040995713666922e5b145443483b48386475c9f47-0a5eb0c0.jpg)

  
> mysql服务地址可用下面的，防止中文乱码  
```  
jdbc:mysql://127.0.0.1:3306/openfire?rewriteBatchedStatements=true&amp;amp;characterEncoding=UTF-8&amp;amp;characterSetResults=UTF-8  
```  
4、管理员设置  

![1559041768769fec13abbd2d5436d8c2c7e4b3a759526.jpg](https://img.hacpai.com/file/2019/08/1559041768769fec13abbd2d5436d8c2c7e4b3a759526-b53a51f9.jpg)

>请记住管理员密码，后面登录时使用，忘记了也可以登录 sql 客户端进行修改的  
  
到这里就配置完成了，登录后如下：  
  
  ![1559041820259f629d1fc029044169cb361101f0eff19.jpg](https://img.hacpai.com/file/2019/08/1559041820259f629d1fc029044169cb361101f0eff19-a4de39ed.jpg)

  
### 未完待续 ###