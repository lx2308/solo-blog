title: Tomcat 配置 https
date: '2018-09-18 19:34:50'
updated: '2018-09-18 19:34:50'
tags: [java]
permalink: /articles/2018/09/18/1537270490000.html
---
Tomcat 7.0以上和以下是两种配置方式，本文基于 tomcat 9.0 配置说明。  
  
#### 1、证书的获取和生成  
我这里是直接在阿里云免费获取的证书  
 ![1558797768146c46d774f43ac48ef9bc964cb5f693526.jpg](https://img.hacpai.com/file/2019/08/1558797768146c46d774f43ac48ef9bc964cb5f693526-68f654b2.jpg)

  
然后点击下载 Tomcat 类型的证书  
  ![15587979142950545e88bdfd542c6a36ab7b59a4eae9b.jpg](https://img.hacpai.com/file/2019/08/15587979142950545e88bdfd542c6a36ab7b59a4eae9b-a1cfaba4.jpg)
#### 2、Tomcat 的配置  
  
打开 server.xml  
  
```  
<Connector port="443" protocol="org.apache.coyote.http11.Http11NioProtocol"  
               maxThreads="150" SSLEnabled="true">  
        <SSLHostConfig>  
            <Certificate certificateKeystoreFile="你的证书路径.pfx"  
                         certificateKeystorePassword="证书密码"  
                         certificateKeystoreType="PKCS12"  
                          />  
        </SSLHostConfig>  
</Connector>  
```  
  
设置普通 http 转 https  
  
```  
<Connector port="80" protocol="HTTP/1.1"  
               connectionTimeout="20000"  
               redirectPort="443" />  
```  
 浏览器输入就好了，出现了久违的小锁子  
   
![1558798222349d70f50c33f574ba0bd630e97b5871a13thumbnail.jpg](https://img.hacpai.com/file/2019/08/1558798222349d70f50c33f574ba0bd630e97b5871a13thumbnail-c0bdeb97.jpg)
